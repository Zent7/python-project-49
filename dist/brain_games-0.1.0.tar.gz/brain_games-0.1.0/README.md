### Hexlet tests and linter status:
[![Actions Status](https://github.com/Zent7/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Zent7/python-project-49/actions)